Freenom WHMCS module install notes.
=====================================================================

To install the WHMCS module, you need to do the following:

Copy the files:
./modules/registrars/freenom/freenom.php
./modules/registrars/freenom/logo.gif

to <your WHMCS path>/modules/registrars/freenom/

Then go to your WHMCS admin panel, go to 
Setup -> Products/Services -> Domain Registrars

Find the Freenom entry, Activate it, and then configure it. Under 
configuration you will need to enter your Freenom credentials.


Because WHMCS has different states than our Freeom API allows, 
you need to install our update of the WHMCS states list.

Copy ./includes/jscript/statesdropdown.js
to <your WHMCS path>/includes/jscript/


Then, to have proper support for TLD's that run at Freenom, copy 
the file ./includes/whoisservers.php to <your WHMCS path>/includes/


Thats it! You are ready to sell domain names paying only cost-price!

