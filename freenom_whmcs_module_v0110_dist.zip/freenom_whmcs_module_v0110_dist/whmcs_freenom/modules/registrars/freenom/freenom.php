<?php

/**
 *
 * Freenom WHMCS module
 * 
 * Please sign up at partners.freenom.com to get an account.
 *
 * Last update:
 * $Date: 2014-09-03 15:04:14 +0200 (Wed, 03 Sep 2014) $
 *
 * */

function freenom_getConfigArray() {                 // {{{
    $configarray = array(
        "FriendlyName" => array("Type" => "System", "Value" => "Freenom"),
        "account_email" => array("Type" => "text", "Size" => "40", "Description" => "Enter your registered email address here"),
        "account_password" => array("Type" => "password", "Size" => "20", "Description" => "Enter your password here"),
    );
    return $configarray;
}

// }}}

function freenom_IDProtectToggle($params) {         // {{{
    $domain = $params["sld"] . "." . $params["tld"];
    $idshield = $params['protectenable'] ? 'enabled' : 'disabled';
    $result = array( 'error' => '',);

    // Get domain response (used for loading default contact data / nameservers for domain)
    $domainGetInfoParams = array(
        "email" => $params["account_email"],
        "password" => $params["account_password"],
    );
    $domainGetInfoParams['function'] = 'domain/getinfo';
    $domainGetInfoQuery = freenom_buildquery(array(
            "email" => $params["account_email"],
            "password" => $params["account_password"],
            "domainname" => $domain,
            "method" => 'GET'
        )
    );

    $domainGetInfoResponse = freenom_put($domainGetInfoQuery, "POST", $domainGetInfoParams);

    // Return error when domain/getinfo failed
    if (!$domainGetInfoResponse || $domainGetInfoResponse->status == 'error') {
        return array('error' => $domainGetInfoResponse->error);
    }

    // Create
    $domainModifyParams = array(
        "email" => $params["account_email"],
        "password" => $params["account_password"],
        "function" => "domain/modify",
    );
    
    $qstring = array(
        "email" => $params["account_email"],
        "password" => $params["account_password"],
        "domainname" => $domain,
        "idshield" => $idshield,
        "method" => "PUT",
    );

    if ($domainGetInfoResponse->domain[0]->forward_url) {
        $qstring["forward_url"] = $domainGetInfoResponse->domain[0]->forward_url;
    }

    foreach ($domainGetInfoResponse->domain[0]->nameserver as $k => $ns) {
        $qstring['nameserver' . ($k + 1)] = $ns->hostname;
    }

    $query = freenom_buildquery($qstring);
    $query = preg_replace("/\[(?:[0-9]|[1-9][0-9]+)\]=/", "=", $query);
    $query = preg_replace("/%5B(?:[0-9]|[1-9][0-9]+)%5D=/", "=", $query);
    $response = freenom_put($query, "POST", $domainModifyParams);

    if ($response->error) {
        $result['error'] = $response->error;
    }

    return $result;
}
// }}}

function freenom_GetNameservers($params) {          // {{{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params["function"] = "domain/getinfo";

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "domainname" => $domainname,
                "method" => "GET",
            )
    );
    $response = freenom_put($query, "GET", $params);

    $return["ns1"] = $response->domain[0]->nameserver[0]->hostname;
    $return["ns2"] = $response->domain[0]->nameserver[1]->hostname;
    $return["ns3"] = $response->domain[0]->nameserver[2]->hostname;
    $return["ns4"] = $response->domain[0]->nameserver[3]->hostname;
    $return["ns5"] = $response->domain[0]->nameserver[4]->hostname;

    if ($response->error) {
        return array("error" => $response->error);
    }
    return $return;
}

// }}}

function freenom_SaveNameservers($params) {         // {{{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'domain/modify';

    $qstring = array(
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "domainname" => $domainname,
        "method" => "PUT",
    );
    $nameserver1 = $params["ns1"];
    $nameserver2 = $params["ns2"];
    $nameserver3 = $params["ns3"];
    $nameserver4 = $params["ns4"];
    $nameserver5 = $params["ns5"];

    if ($nameserver1) {
        $qstring["nameserver1"] = $nameserver1;
    }
    if ($nameserver2) {
        $qstring["nameserver2"] = $nameserver2;
    }
    if ($nameserver3) {
        $qstring["nameserver3"] = $nameserver3;
    }
    if ($nameserver4) {
        $qstring["nameserver4"] = $nameserver4;
    }
    if ($nameserver5) {
        $qstring["nameserver5"] = $nameserver5;
    }

    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }
}

// }}}

function freenom_RegisterDomain($params) {          // {{{
    // Detect if this is a free domain registration linked to a product/service
    $domainname = $params['sld'] . "." . $params['tld'];
    $result = full_query("select 1 from tbldomains d, tblhosting h where h.domain = '$domainname' and d.firstpaymentamount = 0.00 and d.domain = h.domain;");
    $data = mysql_fetch_array($result);
    $freedomain = $data[0];

    if ($freedomain == "1") {
        return freenom_RegisterFreeDomain($params);
    } else {
        return freenom_RegisterPaidDomain($params);
    }
}

// }}}

function freenom_RegisterFreeDomain($params) {      // {{{
    $domainname = $params['sld'] . "." . $params['tld'];
    $params['function'] = 'domain/register';

    $qstring = array(
        "function" => 'domain/register',
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "domainname" => $domainname,
        "domaintype" => "FREE",
        "period" => '12M',
        "method" => "POST",
    );

    if ($params['ns1']) {
        $qstring["nameserver1"] = $params['ns1'];
    }
    if ($params['ns2']) {
        $qstring["nameserver2"] = $params['ns2'];
    }
    if ($params['ns3']) {
        $qstring["nameserver3"] = $params['ns3'];
    }
    if ($params['ns4']) {
        $qstring["nameserver4"] = $params['ns4'];
    }
    if ($params['ns5']) {
        $qstring["nameserver5"] = $params['ns5'];
    }

    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    /* catch generic error */
    if ($response->status == 'error') {
        return array("error" => $response->error);
    }

    if ($response->domain['0']->status != 'REGISTERED') {
        return array("error" => $response->domain['0']->status);
    }
    return $response;
}

// }}}

function freenom_RegisterPaidDomain($params) {      // {{{
    $owner_id = null;
    $admin_id = null;

    if ($params['idprotection'] != 1) {
        // create owner contact
        $params['function'] = 'contact/register';
        $qstring = array(
            "email" => $params['account_email'],
            "password" => $params['account_password'],
            'contact_firstname' => $params["firstname"],
            'contact_lastname' => $params["lastname"],
            'contact_organization' => $params["companyname"],
            'contact_address' => $params["address1"] . " " . $params["address2"],
            'contact_city' => $params["city"],
            'contact_zipcode' => $params["postcode"],
            'contact_statecode' => $params["state"],
            'contact_countrycode' => $params["country"],
            'contact_phone' => $params["phonenumber"],
            'contact_email' => $params["email"],
            'method' => 'PUT',
        );

        $query = freenom_buildquery($qstring);
        $response = freenom_put($query, "POST", $params);

        /* catch generic error */
        if ($response->status == 'error') {
            return array("error" => $response->error);
        }

        $owner_id = $response->contact[0]->contact_id;

        // create admin contact (use for others as well)
        $params['function'] = 'contact/register';
        $qstring = array(
            "email" => $params['account_email'],
            "password" => $params['account_password'],
            'contact_firstname' => $params["adminfirstname"],
            'contact_lastname' => $params["adminlastname"],
            'contact_organization' => $params["admincompanyname"],
            'contact_address' => $params["adminaddress1"] . " " . $params["adminaddress2"],
            'contact_city' => $params["admincity"],
            'contact_zipcode' => $params["adminpostcode"],
            'contact_statecode' => $params["adminstate"],
            'contact_countrycode' => $params["admincountry"],
            'contact_phone' => $params["adminphonenumber"],
            'contact_email' => $params["adminemail"],
            'method' => 'PUT',
        );

        $query = freenom_buildquery($qstring);
        $response = freenom_put($query, "POST", $params);

        /* catch generic error */
        if ($response->status == 'error') {
            return array("error" => $response->error);
        }

        $admin_id = $response->contact[0]->contact_id;
    }

    // register domain
    $params['function'] = 'domain/register';
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;
    $regperiod = $params["regperiod"] . 'Y';
    $nameserver1 = $params["ns1"];
    $nameserver2 = $params["ns2"];
    $nameserver3 = $params["ns3"];
    $nameserver4 = $params["ns4"];
    $nameserver5 = $params["ns5"];
    $method = "POST";

    $qstring = array(
        "function" => 'domain/register',
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "domainname" => $domainname,
        "domaintype" => "PAID",
        "period" => $regperiod,
        "idshield" => $params['idprotection'] == 1 ? 'enabled' : 'disabled',
        "owner_id" => $owner_id,
        "admin_id" => $admin_id,
        "billing_id" => $admin_id,
        "tech_id" => $admin_id,
        "method" => "POST",
    );

    if ($nameserver1) {
        $qstring["nameserver1"] = $nameserver1;
    }
    if ($nameserver2) {
        $qstring["nameserver2"] = $nameserver2;
    }
    if ($nameserver3) {
        $qstring["nameserver3"] = $nameserver3;
    }
    if ($nameserver4) {
        $qstring["nameserver4"] = $nameserver4;
    }
    if ($nameserver5) {
        $qstring["nameserver5"] = $nameserver5;
    }

    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    /* catch generic error */
    if ($response->status == 'error') {
        return array("error" => $response->error);
    }

    if ($response->domain['0']->status != 'REGISTERED') {
        return array("error" => $response->domain['0']->status);
    }
    return $response;
}

// }}}

function freenom_RenewDomain($params) {             // {{{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'domain/renew';
    $regperiod = $params["regperiod"] . 'Y';

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "domainname" => $domainname,
                "period" => $regperiod,
                "method" => "POST",
            )
    );
    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }
}

// }}}

function freenom_GetContactDetails($params) {       // {{{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'domain/getinfo';

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "domainname" => $domainname,
                "method" => 'GET'
            )
    );

    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }

    # owner data
    $values["Registrant"]["First Name"] = $response->domain[0]->owner_contact->contact_firstname;
    $values["Registrant"]["Last Name"] = $response->domain[0]->owner_contact->contact_lastname;
    $values["Registrant"]["Company"] = $response->domain[0]->owner_contact->contact_organization;
    $values["Registrant"]["Address"] = $response->domain[0]->owner_contact->contact_address;
    $values["Registrant"]["City"] = $response->domain[0]->owner_contact->contact_city;
    $values["Registrant"]["Zip Code"] = $response->domain[0]->owner_contact->contact_zipcode;
    $values["Registrant"]["State"] = $response->domain[0]->owner_contact->contact_statecode;
    $values["Registrant"]["Country"] = $response->domain[0]->owner_contact->contact_countrycode;
    $values["Registrant"]["Email"] = $response->domain[0]->owner_contact->contact_email;
    $values["Registrant"]["Telephone"] = $response->domain[0]->owner_contact->contact_phone;
    $values["Registrant"]["Fax"] = $response->domain[0]->owner_contact->contact_fax;

    # admin data
    $values["Admin"]["First Name"] = $response->domain[0]->admin_contact->contact_firstname;
    $values["Admin"]["Last Name"] = $response->domain[0]->admin_contact->contact_lastname;
    $values["Admin"]["Company"] = $response->domain[0]->admin_contact->contact_organization;
    $values["Admin"]["Address"] = $response->domain[0]->admin_contact->contact_address;
    $values["Admin"]["City"] = $response->domain[0]->admin_contact->contact_city;
    $values["Admin"]["Zip Code"] = $response->domain[0]->admin_contact->contact_zipcode;
    $values["Admin"]["State"] = $response->domain[0]->admin_contact->contact_statecode;
    $values["Admin"]["Country"] = $response->domain[0]->admin_contact->contact_countrycode;
    $values["Admin"]["Email"] = $response->domain[0]->admin_contact->contact_email;
    $values["Admin"]["Telephone"] = $response->domain[0]->admin_contact->contact_phone;
    $values["Admin"]["Fax"] = $response->domain[0]->admin_contact->contact_fax;

    # Tech data
    $values["Tech"]["First Name"] = $response->domain[0]->tech_contact->contact_firstname;
    $values["Tech"]["Last Name"] = $response->domain[0]->tech_contact->contact_lastname;
    $values["Tech"]["Company"] = $response->domain[0]->tech_contact->contact_organization;
    $values["Tech"]["Address"] = $response->domain[0]->tech_contact->contact_address;
    $values["Tech"]["City"] = $response->domain[0]->tech_contact->contact_city;
    $values["Tech"]["State"] = $response->domain[0]->tech_contact->contact_statecode;
    $values["Tech"]["Zip Code"] = $response->domain[0]->tech_contact->contact_zipcode;
    $values["Tech"]["Country"] = $response->domain[0]->tech_contact->contact_countrycode;
    $values["Tech"]["Email"] = $response->domain[0]->tech_contact->contact_email;
    $values["Tech"]["Telephone"] = $response->domain[0]->tech_contact->contact_phone;
    $values["Tech"]["Fax"] = $response->domain[0]->tech_contact->contact_fax;

    return $values;
}

// }}}

function freenom_SaveContactDetails($params) {      // {{{
    # get info on the domain
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    # owner data
    $params['function'] = 'contact/register';
    $qstring = array(
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "contact_firstname" => $params["contactdetails"]["Registrant"]["First Name"],
        "contact_lastname" => $params["contactdetails"]["Registrant"]["Last Name"],
        "contact_organization" => $params["contactdetails"]["Registrant"]["Company"],
        "contact_address" => $params["contactdetails"]["Registrant"]["Address"],
        "contact_city" => $params["contactdetails"]["Registrant"]["City"],
        "contact_countrycode" => $params["contactdetails"]["Registrant"]["Country"],
        "contact_statecode" => $params["contactdetails"]["Registrant"]["State"],
        "contact_zipcode" => $params["contactdetails"]["Registrant"]["Zip Code"],
        "contact_email" => $params["contactdetails"]["Registrant"]["Email"],
        "contact_phone" => $params["contactdetails"]["Registrant"]["Telephone"],
        "contact_fax" => $params["contactdetails"]["Registrant"]["Fax"],
        'method' => 'PUT',
    );
    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    /* catch generic error */
    if ($response->status == 'error') {
        return array("error" => $response->error);
    }
    $owner_id = $response->contact[0]->contact_id;

    # Admin data
    $params['function'] = 'contact/register';
    $qstring = array(
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "contact_firstname" => $params["contactdetails"]["Admin"]["First Name"],
        "contact_lastname" => $params["contactdetails"]["Admin"]["Last Name"],
        "contact_organization" => $params["contactdetails"]["Admin"]["Company"],
        "contact_address" => $params["contactdetails"]["Admin"]["Address"],
        "contact_city" => $params["contactdetails"]["Admin"]["City"],
        "contact_countrycode" => $params["contactdetails"]["Admin"]["Country"],
        "contact_statecode" => $params["contactdetails"]["Admin"]["State"],
        "contact_zipcode" => $params["contactdetails"]["Admin"]["Zip Code"],
        "contact_email" => $params["contactdetails"]["Admin"]["Email"],
        "contact_phone" => $params["contactdetails"]["Admin"]["Telephone"],
        "contact_fax" => $params["contactdetails"]["Admin"]["Fax"],
        'method' => 'PUT',
    );
    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    /* catch generic error */
    if ($response->status == 'error') {
        return array("error" => $response->error);
    }
    $admin_id = $response->contact[0]->contact_id;

    # Tech data
    $params['function'] = 'contact/register';
    $qstring = array(
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "contact_firstname" => $params["contactdetails"]["Tech"]["First Name"],
        "contact_lastname" => $params["contactdetails"]["Tech"]["Last Name"],
        "contact_organization" => $params["contactdetails"]["Tech"]["Company"],
        "contact_address" => $params["contactdetails"]["Tech"]["Address"],
        "contact_city" => $params["contactdetails"]["Tech"]["City"],
        "contact_statecode" => $params["contactdetails"]["Tech"]["State"],
        "contact_countrycode" => $params["contactdetails"]["Tech"]["Country"],
        "contact_zipcode" => $params["contactdetails"]["Tech"]["Zip Code"],
        "contact_email" => $params["contactdetails"]["Tech"]["Email"],
        "contact_phone" => $params["contactdetails"]["Tech"]["Telephone"],
        "contact_fax" => $params["contactdetails"]["Tech"]["Fax"],
        'method' => 'PUT',
    );
    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    /* catch generic error */
    if ($response->status == 'error') {
        return array("error" => $response->error);
    }
    $tech_id = $response->contact[0]->contact_id;

    # get current ns/whois settings
    $params['function'] = 'domain/getinfo';
    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "domainname" => $domainname,
                "method" => 'GET'
            )
    );

    $response = freenom_put($query, "POST", $params);
    if ($response->error) {
        return array("error" => $response->error);
    }

    $params['function'] = 'domain/modify';
    $qstring = array(
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "domainname" => $domainname,
        "owner_id" => $owner_id,
        "admin_id" => $admin_id,
        "billing_id" => $admin_id,
        "tech_id" => $tech_id,
        "method" => "PUT",
    );

    // set some values if needed
    if ($response->domain[0]->forward_url) {
        $qstring["forward_url"] = $response->domain[0]->forward_url;
    }
    if ($response->domain[0]->nameserver[0]->hostname) {
        $qstring["nameserver1"] = $response->domain[0]->nameserver[0]->hostname;
    }
    if ($response->domain[0]->nameserver[1]->hostname) {
        $qstring["nameserver2"] = $response->domain[0]->nameserver[1]->hostname;
    }
    if ($response->domain[0]->nameserver[2]->hostname) {
        $qstring["nameserver3"] = $response->domain[0]->nameserver[2]->hostname;
    }
    if ($response->domain[0]->nameserver[3]->hostname) {
        $qstring["nameserver4"] = $response->domain[0]->nameserver[3]->hostname;
    }
    if ($response->domain[0]->nameserver[4]->hostname) {
        $qstring["nameserver5"] = $response->domain[0]->nameserver[4]->hostname;
    }

    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }
}

// }}}

function freenom_RegisterNameserver($params) {      // {{{
    // get domain id
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'nameserver/register';
    $nameserver = $params["nameserver"];
    $ipaddress = $params["ipaddress"];

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "hostname" => $nameserver,
                "domainname" => $domainname,
                "ipaddress" => $ipaddress,
                "method" => 'PUT',
            )
    );
    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }
    return "success";
}

// }}}

function freenom_ModifyNameserver($params) {        // {{{
    // get domain id
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'nameserver/register';
    $nameserver = $params["nameserver"];
    $ipaddress = $params["newipaddress"];

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "hostname" => $nameserver,
                "domainname" => $domainname,
                "ipaddress" => $ipaddress,
                "method" => 'PUT',
            )
    );
    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }

    return "success";
}

// }}}

function freenom_DeleteNameserver($params) {        // {{{
    // get domain id
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'nameserver/delete';
    $nameserver = $params["nameserver"];
    $ipaddress = $params["ipaddress"];

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "domainname" => $domainname,
                "hostname" => $nameserver,
                "ipaddress" => $ipaddress,
                "method" => 'DELETE',
            )
    );
    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }

    return "success";
}

// }}}

function freenom_GetEPPCode($params) {              // {{{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'domain/getinfo';

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "domainname" => $domainname,
                "method" => 'GET'
            )
    );

    $response = freenom_put($query, "POST", $params);

    if ($response->error) {
        return array("error" => $response->error);
    }

    # auth code
    $values["eppcode"] = $response->domain[0]->authcode;

    return $values;
}

// }}}

function freenom_Sync($params) {                    // {{{
    // get domain id
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    $params['function'] = 'domain/getinfo';

    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "userid" => $client["userid"],
                "domainname" => $domainname,
                "method" => 'GET'
            )
    );

    $response = freenom_put($query, "POST", $params);
    if ($response->error and $response->error != 'Not your domain') {
        return array("error" => $response->error);
    }

    $values = array();

    if ($response->domain[0]->status == 'ACTIVE') {
        $values["active"] = true;
        $values["expired"] = false;
        $values["expirydate"] = preg_replace("/(\d{4})(\d{2})(\d{2})/", "$1-$2-$3", $response->domain[0]->expirationdate);

        // not your domain? it expired then.
    } elseif ($response->error and $response->error == 'Not your domain') {
        $values["active"] = false;
        $values["expired"] = true;

        // only return expired if a domain is returned, but appaerently not ACTIVE
    } elseif (isset($response->domain[0])) {
        $values["active"] = false;
        $values["expired"] = true;
    }

    return $values; # return the details of the sync
}

// }}}

function freenom_TransferDomain($params) {          // {{{
    $tld = $params["tld"];
    $sld = $params["sld"];
    $domainname = $sld . "." . $tld;

    // create new owner contact
    $params['function'] = 'contact/register';
    $qstring = array(
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "method" => "PUT",
        'contact_firstname' => $params["firstname"],
        'contact_lastname' => $params["lastname"],
        'contact_organization' => $params["company"],
        'contact_address' => $params["address1"] . " " . $params["address2"],
        'contact_city' => $params["city"],
        'contact_zipcode' => $params["postcode"],
        'contact_statecode' => $params["state"],
        'contact_countrycode' => $params["country"],
        'contact_phone' => $params["phonenumber"],
        'contact_fax' => $params["faxnumber"],
        'contact_email' => $params["email"],
    );

    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    /* catch generic error */
    if ($response->status == 'error') {
        return array("error" => $response->error);
    }

    // set variables
    $regperiod = $params["regperiod"] . 'Y';
    $owner_id = $response->contact[0]->contact_id;
    $transfersecret = $params["transfersecret"];
    $nameserver1 = $params["ns1"];
    $nameserver2 = $params["ns2"];
    // are there more?
    // init transfer
    $params['function'] = 'domain/transfer/request';
    $qstring = array(
        "email" => $params['account_email'],
        "password" => $params['account_password'],
        "method" => "POST",
        "domainname" => $domainname,
        "authcode" => $transfersecret,
        "owner_id" => $owner_id,
        "period" => $regperiod,
    );

    $query = freenom_buildquery($qstring);
    $response = freenom_put($query, "POST", $params);

    /* catch generic error */
    if ($response->status == 'error') {
        return array("error" => $response->error);
    }
}

/// }}}

function freenom_TransferSync($params) {            // {{{
    // to be returned
    $values = array();

    // get client_data
    $domainname = $params['sld'] . "." . $params['tld'];

    # make the call to list transfer domains
    $params['function'] = 'domain/transfer/list';
    $query = freenom_buildquery(
            array(
                "email" => $params['account_email'],
                "password" => $params['account_password'],
                "method" => 'GET'
            )
    );

    $response = freenom_put($query, "POST", $params);
    if ($response->error) {
        return array("error" => $response->error);
    }

    # now get details on the requested domain.
    foreach ($response->transfer as $transfer) {
        $search_domain = strtoupper($domainname);

        if ($transfer->domainname == $search_domain && $transfer->status != 'PENDING') {
            # approved? Or declined?
            if ($transfer->status == 'APPROVED') {

                // get domain expiry date
                $in_params['function'] = 'domain/getinfo';
                $in_query = freenom_buildquery(
                        array(
                            "email" => $params['account_email'],
                            "password" => $params['account_password'],
                            "domainname" => $domainname,
                            "method" => 'GET'
                        )
                );
                $in_response = freenom_put($in_query, "POST", $in_params);

                logActivity("Marking " . $search_domain . " transfer as approved");
                logActivity("Marking " . $search_domain . " as " . $in_response->domain[0]->expirationdate);

                $values['expirydate'] = preg_replace("/(\d{4})(\d{2})(\d{2})/", "$1-$2-$3", $in_response->domain[0]->expirationdate);
                $values['completed'] = true;
            }

            if ($transfer->status == 'DECLINED') {
                logActivity("Marking " . $search_domain . " transfer as declined");
                $values['failed'] = true;
                $values['reason'] = "Transfer declined";
            }
            return $values;
        }
    }
}

// }}}

function freenom_put($xml, $callmethod, $params) {  // {{{
    $xurl = "http://api.freenom.com/v2/" . $params["function"] . ".json";
    $headers = array("Accept: application/x-www-form-urlencoded", "Content-Type: application/x-www-form-urlencoded");
    $session = curl_init();
    curl_setopt($session, CURLOPT_URL, $xurl);
    curl_setopt($session, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
    curl_setopt($session, CURLOPT_POSTFIELDS, $xml);
    curl_setopt($session, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($session, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($session, CURLOPT_SSL_VERIFYPEER, false);
    $response = curl_exec($session);
    $action = explode("=", $action[0]);
    $action = end($action);

    if (curl_errno($session)) {
        return array(
            'error' => 'curl error: ' . curl_errno($session) . " - " . curl_error($session),
            'status' => 'error'
        );
        curl_close($session);
        return $data;
    }
    curl_close($session);
    return json_decode($response);
}

// }}}

function freenom_buildquery($formdata) {            // {{{
    $query = "";
    foreach ($formdata as $k => $v) {
        if (substr($k, 0, 10) == "nameserver") {
            $k = "nameserver";
        }
        $query .= "" . $k . "=" . urlencode($v) . "&";
    }
    return $query;
}

// }}}

?>
